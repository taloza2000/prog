#Ресурсы студенческого сообщества ЮГУ
|Название ресурса|Ссылка|Внешний вид ресурса|
|----------------|------|-------------------|
|ЮГУ: Югорский государственный университет (группа в ВК)|[https://vk.com/ugrasu](https://vk.com/ugrasu)|![:](https://pp.userapi.com/c851236/v851236495/c8738/vML3omhx52U.jpg)
|Студенческий медиацентр ЮГУ|[https://vk.com/stud_smi_ugrasu](https://vk.com/stud_smi_ugrasu)|![:](https://sun1-17.userapi.com/c850432/v850432439/53904/8kUvs3v9gtM.jpg?ava=1)
|YouTube канал ЮГУ|[Канал](https://www.youtube.com/channel/UCx43iULpSe_8zHtW2htXTtw/featured)|![:](https://pp.userapi.com/c836530/v836530261/2eaa0/nsLEmsR0U-I.jpg?ava=1)