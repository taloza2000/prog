# Полезные ссылки
##Markdown
####Это упрощенный язык разметки для веб-страниц
0. [Шпаргалка](http://konvut.github.io/k50articles/)
0. [Интерактивный учебник](https://paulradzkov.com/2014/markdown_cheatsheet/)

##Git
####Это система контроля версий для текстовых файлов 
0. [Ссылка для скачивания (Осторожно консоль)](https://git-scm.com/) 
0. Документация

##Github
####Это репозиторий для проектов созданных с помощью git
0. [Официальный сайт](https://github.com/account/unverified-email)
0. [Краткая инструкция по созданию репозитория](file:///C:/Users/Admin/AppData/Local/Packages/Microsoft.MicrosoftEdge_8wekyb3d8bbwe/TempState/Downloads/progit_v2.1.3%20(1).pdf)

##Mkdocs
####Это программа для сборки сайта
0. [Официальный сайт](https://www.mkdocs.org/) На английском
0. [Видеоурок по ручной настройка](https://vertex-academy.com/tutorials/ru/kak-sozdat-repozitorij-na-github/) На английском (используйте субтитры)

##Python
####Это язык программирования на котором работает mkdocs.
0. Для ручной установки вам будет необходимо установить все самим [Как установить Python()](https://python-scripts.com/install-python)