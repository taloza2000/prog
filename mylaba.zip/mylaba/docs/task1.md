# Полезные ресурсы ЮГУ

## Официальный сайт ЮГУ
[ugrasu.ru](https://www.ugrasu.ru)